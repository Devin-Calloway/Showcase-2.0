package com.example.intent;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class PokemonCardAdapter extends RecyclerView.Adapter<PokemonCardAdapter.ViewHolder> {

    private final List<PokemonData> pokemonList;

    public PokemonCardAdapter(List<PokemonData> pokemonList) {
        this.pokemonList = pokemonList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pokemoncard, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PokemonData data = pokemonList.get(position);

        holder.name.setText(data.name.substring(0, 1).toUpperCase() + data.name.substring(1));
        holder.hp.setText(String.valueOf(data.hp));
        holder.height.setText("Length: " + (data.height / 10.0) + " m");
        holder.weight.setText("Weight: " + (data.weight / 10.0) + " kg");
        holder.description.setText(data.description);
        
        holder.move1Name.setText(data.move1.replace("-", " "));
        holder.move1Power.setText(data.move1Power);
        holder.move2Name.setText(data.move2.replace("-", " "));
        holder.move2Power.setText(data.move2Power);
        
        holder.weakness.setText(data.weakness);
        holder.resistance.setText(data.resistance);

        // Styling based on type
        int baseColor = getTypeColor(data.type);
        holder.background.setBackgroundColor(baseColor);
        
        // Highlight the stats bar with a slightly different shade
        int secondaryColor = adjustAlpha(baseColor, 0.7f);
        holder.statsLayout.setBackgroundColor(secondaryColor);

        Glide.with(holder.itemView.getContext())
                .load(data.imageUrl)
                .placeholder(android.R.drawable.ic_menu_gallery)
                .into(holder.image);
    }

    private int getTypeColor(String type) {
        switch (type.toLowerCase()) {
            case "fire": return Color.parseColor("#F08030");
            case "water": return Color.parseColor("#6890F0");
            case "grass": return Color.parseColor("#78C850");
            case "electric": return Color.parseColor("#F8D030");
            case "psychic": return Color.parseColor("#F85888");
            case "ice": return Color.parseColor("#98D8D8");
            case "dragon": return Color.parseColor("#7038F8");
            case "dark": return Color.parseColor("#705848");
            case "fairy": return Color.parseColor("#EE99AC");
            case "normal": return Color.parseColor("#A8A878");
            case "fighting": return Color.parseColor("#C03028");
            case "flying": return Color.parseColor("#A890F0");
            case "poison": return Color.parseColor("#A040A0");
            case "ground": return Color.parseColor("#E0C068");
            case "rock": return Color.parseColor("#B8A038");
            case "bug": return Color.parseColor("#A8B820");
            case "ghost": return Color.parseColor("#705898");
            case "steel": return Color.parseColor("#B8B8D0");
            default: return Color.parseColor("#A8A878");
        }
    }

    private int adjustAlpha(int color, float factor) {
        int alpha = Math.round(Color.alpha(color) * factor);
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);
        return Color.argb(alpha, red, green, blue);
    }

    @Override
    public int getItemCount() {
        return pokemonList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, hp, height, weight, description, move1Name, move1Power, move2Name, move2Power, weakness, resistance;
        ImageView image;
        View background, statsLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.pokemonNameTextView);
            hp = itemView.findViewById(R.id.pokemonHPTextView);
            height = itemView.findViewById(R.id.pokemonLengthTextView);
            weight = itemView.findViewById(R.id.pokemonWeightTextView);
            description = itemView.findViewById(R.id.pokemonDescriptionTextView);
            move1Name = itemView.findViewById(R.id.pokemonMove1TextView);
            move1Power = itemView.findViewById(R.id.pokemonMove1PowerTextView);
            move2Name = itemView.findViewById(R.id.pokemonMove2TextView);
            move2Power = itemView.findViewById(R.id.pokemonMove2PowerTextView);
            weakness = itemView.findViewById(R.id.pokemonWeaknessTextView);
            resistance = itemView.findViewById(R.id.pokemonResistanceTextView);
            image = itemView.findViewById(R.id.pokemonImageView);
            background = itemView.findViewById(R.id.cardBackground);
            statsLayout = itemView.findViewById(R.id.pokemonStatsLayout);
        }
    }
}
